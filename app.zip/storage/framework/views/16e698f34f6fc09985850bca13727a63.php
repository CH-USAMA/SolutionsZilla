<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e($patient->name); ?>

            </h2>
            <a href="<?php echo e(route('patients.edit', $patient)); ?>"
                class="inline-flex items-center px-4 py-2 bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-500 transition">
                Edit Profile
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Patient Info -->
                <div class="col-span-1">
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-4 border-b pb-2">Profile</h3>
                        <dl class="text-sm text-gray-600 space-y-3">
                            <div>
                                <dt class="font-bold text-gray-900">Phone</dt>
                                <dd><?php echo e($patient->phone); ?></dd>
                            </div>
                            <div>
                                <dt class="font-bold text-gray-900">Email</dt>
                                <dd><?php echo e($patient->email ?? '-'); ?></dd>
                            </div>
                            <div>
                                <dt class="font-bold text-gray-900">Age / Gender</dt>
                                <dd><?php echo e($patient->age ? $patient->age . ' years' : '-'); ?> /
                                    <?php echo e(ucfirst($patient->gender ?? '-')); ?>

                                </dd>
                            </div>
                            <div>
                                <dt class="font-bold text-gray-900">Address</dt>
                                <dd><?php echo e($patient->address ?? '-'); ?></dd>
                            </div>
                            <div>
                                <dt class="font-bold text-gray-900">Medical History</dt>
                                <dd class="mt-1 p-2 bg-yellow-50 rounded">
                                    <?php echo e($patient->medical_history ?? 'No records.'); ?>

                                </dd>
                            </div>
                        </dl>
                    </div>
                </div>

                <!-- Appointment History -->
                <div class="col-span-1 md:col-span-2">
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                        <h3 class="text-lg font-medium text-gray-900 mb-4 border-b pb-2">Appointment History</h3>

                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                                            Date/Time</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                                            Doctor</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                                            Status</th>
                                        <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                    <?php $__empty_1 = true; $__currentLoopData = $patient->appointments()->latest('appointment_date')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="px-4 py-3 text-sm">
                                                <div class="font-medium">
                                                    <?php echo e($appointment->appointment_date->format('M d, Y')); ?>

                                                </div>
                                                <div class="text-gray-500">
                                                    <?php echo e(date('h:i A', strtotime($appointment->appointment_time))); ?>

                                                </div>
                                            </td>
                                            <td class="px-4 py-3 text-sm"><?php echo e($appointment->doctor->name); ?></td>
                                            <td class="px-4 py-3 text-sm">
                                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                            <?php if($appointment->status === 'confirmed'): ?> bg-green-100 text-green-800
                                                            <?php elseif($appointment->status === 'completed'): ?> bg-gray-100 text-gray-800
                                                            <?php elseif($appointment->status === 'cancelled'): ?> bg-red-100 text-red-800
                                                            <?php else: ?> bg-yellow-100 text-yellow-800 <?php endif; ?>">
                                                    <?php echo e(ucfirst($appointment->status)); ?>

                                                </span>
                                            </td>
                                            <td class="px-4 py-3 text-sm">
                                                <a href="<?php echo e(route('appointments.show', $appointment)); ?>"
                                                    class="text-indigo-600 hover:text-indigo-900">View</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="px-4 py-3 text-center text-gray-500">No appointments
                                                found.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Patient Documents -->
                <div class="col-span-1 md:col-span-3 mt-6">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Patient Documents</h3>
                        </div>
                        <div class="card-body">
                            <!-- Upload Form -->
                            <form action="<?php echo e(route('patients.documents.upload', $patient)); ?>" method="POST"
                                enctype="multipart/form-data" class="mb-6 p-4 bg-gray-50 rounded-lg">
                                <?php echo csrf_field(); ?>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                                    <div class="md:col-span-2">
                                        <label for="document"
                                            class="block text-sm font-medium text-gray-700 mb-2">Upload Document</label>
                                        <input type="file" name="document" id="document"
                                            accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" required
                                            class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-white focus:outline-none">
                                        <p class="mt-1 text-xs text-gray-500">PDF, JPG, PNG, DOC, DOCX (Max: 10MB)</p>
                                    </div>
                                    <div>
                                        <button type="submit" class="btn-primary w-full">
                                            <svg class="w-4 h-4 inline mr-2" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12">
                                                </path>
                                            </svg>
                                            Upload
                                        </button>
                                    </div>
                                </div>
                                <div class="mt-3">
                                    <label for="description"
                                        class="block text-sm font-medium text-gray-700 mb-2">Description
                                        (Optional)</label>
                                    <input type="text" name="description" id="description"
                                        placeholder="e.g., Lab Report, X-Ray, Prescription"
                                        class="block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                </div>
                            </form>

                            <!-- Documents List -->
                            <?php if($patient->documents->count() > 0): ?>
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                    <?php $__currentLoopData = $patient->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                                            <div class="flex items-start justify-between">
                                                <div class="flex-1">
                                                    <div class="flex items-center mb-2">
                                                        <?php if(in_array($document->file_type, ['pdf'])): ?>
                                                            <svg class="w-8 h-8 text-red-500 mr-2" fill="currentColor"
                                                                viewBox="0 0 20 20">
                                                                <path
                                                                    d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z">
                                                                </path>
                                                            </svg>
                                                        <?php elseif(in_array($document->file_type, ['jpg', 'jpeg', 'png'])): ?>
                                                            <svg class="w-8 h-8 text-blue-500 mr-2" fill="currentColor"
                                                                viewBox="0 0 20 20">
                                                                <path fill-rule="evenodd"
                                                                    d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z"
                                                                    clip-rule="evenodd"></path>
                                                            </svg>
                                                        <?php else: ?>
                                                            <svg class="w-8 h-8 text-gray-500 mr-2" fill="currentColor"
                                                                viewBox="0 0 20 20">
                                                                <path fill-rule="evenodd"
                                                                    d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"
                                                                    clip-rule="evenodd"></path>
                                                            </svg>
                                                        <?php endif; ?>
                                                        <div class="flex-1">
                                                            <h4 class="text-sm font-medium text-gray-900 truncate">
                                                                <?php echo e($document->file_name); ?></h4>
                                                            <p class="text-xs text-gray-500">
                                                                <?php echo e(number_format($document->file_size / 1024, 2)); ?> KB</p>
                                                        </div>
                                                    </div>
                                                    <?php if($document->description): ?>
                                                        <p class="text-xs text-gray-600 mb-2"><?php echo e($document->description); ?></p>
                                                    <?php endif; ?>
                                                    <p class="text-xs text-gray-400">
                                                        <?php echo e($document->created_at->format('M d, Y')); ?></p>
                                                </div>
                                            </div>
                                            <div class="mt-3 flex gap-2">
                                                <a href="<?php echo e(asset('storage/' . $document->file_path)); ?>" target="_blank"
                                                    class="flex-1 text-center px-3 py-1.5 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 transition">
                                                    View
                                                </a>
                                                <form action="<?php echo e(route('patients.documents.delete', [$patient, $document])); ?>"
                                                    method="POST" class="flex-1"
                                                    onsubmit="return confirm('Are you sure you want to delete this document?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                        class="w-full px-3 py-1.5 bg-red-600 text-white text-xs rounded hover:bg-red-700 transition">
                                                        Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-8 text-gray-500">
                                    <svg class="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z">
                                        </path>
                                    </svg>
                                    <p>No documents uploaded yet.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\ClinicFlow\laravel\ClinicFlow\resources\views/patients/show.blade.php ENDPATH**/ ?>