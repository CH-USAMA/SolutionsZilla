<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight uppercase tracking-wider">
            Clinic Management
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12 bg-gray-50 min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between mb-8">
                <h1 class="text-2xl font-bold text-gray-900">All Clinics</h1>
                <span class="text-sm text-gray-500"><?php echo e($clinics->count()); ?> clinics registered</span>
            </div>

            <?php if(session('success')): ?>
                <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl" role="alert">
                    <span class="block sm:inline font-medium"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <div class="bg-white shadow-sm border border-gray-100 rounded-xl overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-100">
                        <thead class="bg-gray-50/80">
                            <tr>
                                <th
                                    class="px-6 py-4 text-left text-xs font-bold text-gray-400 uppercase tracking-widest">
                                    Clinic</th>
                                <th
                                    class="px-6 py-4 text-left text-xs font-bold text-gray-400 uppercase tracking-widest">
                                    Current Plan</th>
                                <th
                                    class="px-6 py-4 text-center text-xs font-bold text-gray-400 uppercase tracking-widest">
                                    Users</th>
                                <th
                                    class="px-6 py-4 text-center text-xs font-bold text-gray-400 uppercase tracking-widest">
                                    Doctors</th>
                                <th
                                    class="px-6 py-4 text-center text-xs font-bold text-gray-400 uppercase tracking-widest">
                                    Patients</th>
                                <th
                                    class="px-6 py-4 text-center text-xs font-bold text-gray-400 uppercase tracking-widest">
                                    Appts</th>
                                <th
                                    class="px-6 py-4 text-center text-xs font-bold text-gray-400 uppercase tracking-widest">
                                    Status</th>
                                <th
                                    class="px-6 py-4 text-center text-xs font-bold text-gray-400 uppercase tracking-widest">
                                    Assign Plan</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50/50 transition">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-bold text-gray-900"><?php echo e($clinic->name); ?></div>
                                        <div class="text-xs text-gray-400"><?php echo e($clinic->phone); ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if($clinic->plan): ?>
                                                                    <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold
                                                                                <?php echo e($clinic->plan->slug === 'testing' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                                            ($clinic->plan->slug === 'pro' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' :
                                                ($clinic->plan->slug === 'basic' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                                                    'bg-gray-50 text-gray-600 border border-gray-200'))); ?>">
                                                                        <?php echo e($clinic->plan->name); ?>

                                                                    </span>
                                        <?php else: ?>
                                            <span class="text-xs text-gray-400 italic">No Plan</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-center text-sm font-bold text-gray-700">
                                        <?php echo e($clinic->users_count); ?></td>
                                    <td class="px-6 py-4 text-center text-sm font-bold text-gray-700">
                                        <?php echo e($clinic->doctors_count); ?></td>
                                    <td class="px-6 py-4 text-center text-sm font-bold text-gray-700">
                                        <?php echo e($clinic->patients_count); ?></td>
                                    <td class="px-6 py-4 text-center text-sm font-bold text-blue-600">
                                        <?php echo e($clinic->appointments_count); ?></td>
                                    <td class="px-6 py-4 text-center">
                                        <?php if($clinic->subscription_status === 'active'): ?>
                                            <span
                                                class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-green-50 text-green-700">Active</span>
                                        <?php else: ?>
                                            <span
                                                class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-red-50 text-red-600"><?php echo e(ucfirst($clinic->subscription_status ?? 'N/A')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-center">
                                        <form action="<?php echo e(route('super-admin.clinics.update-plan', $clinic)); ?>" method="POST"
                                            class="inline-flex items-center gap-2">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <select name="plan_id"
                                                class="text-xs border-gray-200 rounded-lg py-1 px-2 focus:ring-indigo-500 focus:border-indigo-500">
                                                <option value="">— No Plan —</option>
                                                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($plan->id); ?>" <?php echo e($clinic->plan_id == $plan->id ? 'selected' : ''); ?>>
                                                        <?php echo e($plan->name); ?> ($<?php echo e(number_format($plan->price, 0)); ?>)
                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button type="submit"
                                                class="inline-flex items-center px-2 py-1 bg-indigo-50 text-indigo-600 rounded-lg text-xs font-bold hover:bg-indigo-100 border border-indigo-200 transition">
                                                Apply
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\ClinicFlow\laravel\ClinicFlow\resources\views/super-admin/clinics.blade.php ENDPATH**/ ?>